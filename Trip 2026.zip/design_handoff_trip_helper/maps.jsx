// maps.jsx — Custom SVG maps (Europe overview + city street map)
// Style: paper / topographic — matches questionnaire choice #3

const { useState: useStateM, useEffect: useEffectM } = React;

// Europe map: hand-drawn style with country shapes
function EuropeMap({ cities, activeId, onCity, dark }) {
  const w = 360, h = 380;
  // Latitude / longitude bounding box for our 4 cities + buffer
  // Roughly: lng 0-22, lat 45-58
  const proj = (lng, lat) => {
    const x = ((lng - (-2)) / 26) * w;
    const y = h - ((lat - 43) / 18) * h;
    return [x, y];
  };

  const points = cities.map(c => ({ ...c, p: proj(c.lng, c.lat) }));

  return (
    <div style={{
      width: '100%', height: '100%',
      background: dark ? '#1a1d23' : '#F2EBDA',
      position: 'relative', overflow: 'hidden',
    }}>
      <svg width="100%" height="100%" viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="xMidYMid slice">
        <defs>
          <pattern id="paper-grid" width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M 20 0 L 0 0 0 20" fill="none" stroke={dark ? '#252830' : '#E5DDC8'} strokeWidth="0.5"/>
          </pattern>
          <pattern id="topo" width="60" height="60" patternUnits="userSpaceOnUse">
            <path d="M0 30 Q 15 20 30 30 T 60 30" fill="none" stroke={dark ? '#2a2e36' : '#D9CFB5'} strokeWidth="0.6" opacity="0.4"/>
            <path d="M0 50 Q 15 40 30 50 T 60 50" fill="none" stroke={dark ? '#2a2e36' : '#D9CFB5'} strokeWidth="0.6" opacity="0.3"/>
          </pattern>
        </defs>

        {/* Background pattern */}
        <rect width={w} height={h} fill="url(#paper-grid)"/>
        <rect width={w} height={h} fill="url(#topo)"/>

        {/* Sea/coast bands */}
        <path d={`M 0 ${h*0.2} Q ${w*0.3} ${h*0.15} ${w*0.7} ${h*0.25} T ${w} ${h*0.2} L ${w} 0 L 0 0 Z`}
              fill={dark ? '#161a20' : '#DDE5D5'} opacity="0.6"/>

        {/* Stylized landmasses (very abstract Europe) */}
        <g fill={dark ? '#22262d' : '#EAE0C5'} stroke={dark ? '#2e333b' : '#C9B896'} strokeWidth="0.8">
          {/* Continental Europe blob */}
          <path d="M -10 130 Q 30 100 80 110 Q 130 90 180 100 Q 230 95 280 115 Q 330 110 380 130 L 380 400 L -10 400 Z"/>
          {/* Scandinavia bump */}
          <path d="M 130 60 Q 160 50 175 70 Q 195 90 200 110 Q 175 105 155 100 Q 140 90 130 60 Z" />
          {/* UK */}
          <path d="M 30 100 Q 45 85 50 100 Q 55 130 40 145 Q 25 130 30 100 Z" />
        </g>

        {/* Borders / rivers */}
        <g stroke={dark ? '#3a3f48' : '#B8A887'} fill="none" strokeWidth="0.7" strokeDasharray="2 3" opacity="0.7">
          <path d="M 100 180 Q 130 200 170 220 T 230 250"/>
          <path d="M 200 200 Q 230 230 250 270"/>
          <path d="M 80 240 Q 120 250 160 270"/>
        </g>

        {/* City labels (background only) */}
        <g fontFamily="'Google Sans', sans-serif" fontSize="9" fill={dark ? '#666c75' : '#9c8e72'} fontWeight="500">
          <text x="60" y="160">UK</text>
          <text x="155" y="80">Norway</text>
          <text x="160" y="200">Germany</text>
          <text x="240" y="280">Czechia</text>
          <text x="100" y="280">France</text>
        </g>

        {/* Route line (curved, dashed) */}
        <g fill="none">
          <path d={routePath(points)} stroke={dark ? '#5a4234' : '#C84F38'} strokeWidth="2" strokeDasharray="6 4" opacity="0.85"/>
          <path d={routePath(points)} stroke={dark ? '#F06B50' : '#F06B50'} strokeWidth="0.8" strokeDasharray="6 4"/>
        </g>

        {/* Numbered city pins */}
        {points.map((c, i) => {
          const active = activeId === c.id;
          return (
            <g key={c.id} onClick={() => onCity(c)} style={{ cursor: 'pointer' }} transform={`translate(${c.p[0]} ${c.p[1]})`}>
              {/* Shadow */}
              <ellipse cx="0" cy="3" rx="11" ry="3" fill="rgba(0,0,0,0.18)" />
              {/* Outer ring */}
              <circle r={active ? 18 : 14} fill={c.color} opacity="0.18" />
              {/* Pin head */}
              <circle r={active ? 13 : 11} fill={c.color} stroke="#fff" strokeWidth="2.5" />
              <text x="0" y="4" textAnchor="middle" fill="#fff" fontFamily="'Google Sans', sans-serif" fontSize="11" fontWeight="700">{i+1}</text>
              {/* Label */}
              <g transform="translate(0 -22)">
                <rect x="-30" y="-9" width="60" height="14" rx="3" fill={dark ? '#0e1014' : '#fff'} opacity="0.92"/>
                <text x="0" y="1" textAnchor="middle" fill={dark ? '#e8e8e8' : '#1f1f1f'} fontFamily="'Google Sans', sans-serif" fontSize="10" fontWeight="600">{c.name}</text>
              </g>
            </g>
          );
        })}

        {/* Compass */}
        <g transform={`translate(${w-40} 40)`} opacity="0.7">
          <circle r="14" fill="none" stroke={dark ? '#3a3f48' : '#B8A887'} strokeWidth="0.8"/>
          <path d="M 0 -12 L 3 0 L 0 4 L -3 0 Z" fill={dark ? '#7a8088' : '#5a4234'}/>
          <text x="0" y="-16" textAnchor="middle" fontSize="7" fill={dark ? '#7a8088' : '#5a4234'} fontFamily="'Google Sans', sans-serif" fontWeight="700">N</text>
        </g>

        {/* Scale */}
        <g transform={`translate(20 ${h-30})`}>
          <line x1="0" y1="0" x2="60" y2="0" stroke={dark ? '#5a6068' : '#5a4234'} strokeWidth="1.5"/>
          <line x1="0" y1="-4" x2="0" y2="4" stroke={dark ? '#5a6068' : '#5a4234'} strokeWidth="1.5"/>
          <line x1="60" y1="-4" x2="60" y2="4" stroke={dark ? '#5a6068' : '#5a4234'} strokeWidth="1.5"/>
          <text x="0" y="14" fill={dark ? '#7a8088' : '#5a4234'} fontSize="9" fontFamily="'Google Sans', sans-serif">500 км</text>
        </g>
      </svg>
    </div>
  );
}

function routePath(points) {
  if (points.length < 2) return '';
  let d = `M ${points[0].p[0]} ${points[0].p[1]}`;
  for (let i = 1; i < points.length; i++) {
    const [x1, y1] = points[i-1].p;
    const [x2, y2] = points[i].p;
    const cx = (x1 + x2) / 2;
    const cy = Math.min(y1, y2) - 30;
    d += ` Q ${cx} ${cy} ${x2} ${y2}`;
  }
  return d;
}

// City street map (procedural)
function CityMap({ city, places, stay, focusId, onPlace, dark }) {
  const w = 400, h = 220;
  // Distribute place pins around stay
  const stayP = [w/2, h/2 + 10];
  const pins = places.map((p, i) => {
    const angle = (i / places.length) * Math.PI * 2 + 0.4;
    const radius = 50 + (i % 3) * 22;
    return { ...p, x: stayP[0] + Math.cos(angle) * radius * 1.4, y: stayP[1] + Math.sin(angle) * radius * 0.85 };
  });

  return (
    <div style={{ width: '100%', height: '100%', background: dark ? '#1a1d23' : '#F2EBDA', position: 'relative', overflow: 'hidden', borderRadius: 24 }}>
      <svg width="100%" height="100%" viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="xMidYMid slice">
        <defs>
          <pattern id={`citygrid-${city.id}`} width="14" height="14" patternUnits="userSpaceOnUse">
            <path d="M 14 0 L 0 0 0 14" fill="none" stroke={dark ? '#23272e' : '#E5DDC8'} strokeWidth="0.4"/>
          </pattern>
        </defs>
        <rect width={w} height={h} fill={`url(#citygrid-${city.id})`}/>

        {/* River */}
        <path d={`M -10 ${h*0.7} Q ${w*0.3} ${h*0.55} ${w*0.55} ${h*0.7} T ${w+10} ${h*0.65}`}
              fill="none" stroke={dark ? '#2a3540' : '#C9DDE8'} strokeWidth="22" strokeLinecap="round" opacity="0.85"/>
        <path d={`M -10 ${h*0.7} Q ${w*0.3} ${h*0.55} ${w*0.55} ${h*0.7} T ${w+10} ${h*0.65}`}
              fill="none" stroke={dark ? '#3a4550' : '#B0D0E0'} strokeWidth="1" opacity="0.8"/>

        {/* Streets — diagonals + radials */}
        <g stroke={dark ? '#33383f' : '#D9CFB5'} fill="none" strokeWidth="1.4" opacity="0.7">
          <path d={`M ${stayP[0]-160} ${stayP[1]-60} L ${stayP[0]+160} ${stayP[1]-60}`}/>
          <path d={`M ${stayP[0]-120} ${stayP[1]-100} L ${stayP[0]+180} ${stayP[1]+10}`}/>
          <path d={`M ${stayP[0]-160} ${stayP[1]+20} L ${stayP[0]+180} ${stayP[1]-30}`}/>
          <path d={`M ${stayP[0]+30} ${stayP[1]-80} L ${stayP[0]-30} ${stayP[1]+90}`}/>
          <path d={`M ${stayP[0]-30} ${stayP[1]-80} L ${stayP[0]+30} ${stayP[1]+90}`}/>
        </g>

        {/* Park blob */}
        <ellipse cx={w-60} cy={50} rx="50" ry="28" fill={dark ? '#22302a' : '#D5E0C8'} opacity="0.7"/>
        <text x={w-60} y={52} textAnchor="middle" fill={dark ? '#5a7060' : '#7a8e6a'} fontSize="8" fontFamily="'Google Sans', sans-serif" fontWeight="600">PARK</text>

        {/* Stay marker */}
        <g transform={`translate(${stayP[0]} ${stayP[1]})`}>
          <circle r="22" fill={city.color} opacity="0.15"/>
          <rect x="-14" y="-14" width="28" height="28" rx="8" fill={city.color} stroke="#fff" strokeWidth="2.5"/>
          <text x="0" y="5" textAnchor="middle" fontSize="14">🏠</text>
        </g>

        {/* Place pins */}
        {pins.map(p => {
          const tagColors = { wow: '#F06B50', kids: '#3B82F6', science: '#8B5CF6', food: '#10B981' };
          const col = tagColors[p.tag] || '#737373';
          const focused = focusId === p.id;
          return (
            <g key={p.id} transform={`translate(${p.x} ${p.y})`} onClick={() => onPlace(p)} style={{ cursor: 'pointer' }}>
              <ellipse cx="0" cy="2" rx="9" ry="2.5" fill="rgba(0,0,0,0.2)"/>
              <circle r={focused ? 14 : 11} fill={col} stroke="#fff" strokeWidth="2"/>
              <text x="0" y="4" textAnchor="middle" fontSize={focused ? 13 : 11}>{p.emoji}</text>
            </g>
          );
        })}

        {/* Scale */}
        <g transform={`translate(14 ${h-18})`}>
          <line x1="0" y1="0" x2="40" y2="0" stroke={dark ? '#5a6068' : '#5a4234'} strokeWidth="1.5"/>
          <text x="0" y="10" fill={dark ? '#7a8088' : '#5a4234'} fontSize="8" fontFamily="'Google Sans', sans-serif">500 м</text>
        </g>
      </svg>
    </div>
  );
}

window.EuropeMap = EuropeMap;
window.CityMap = CityMap;
