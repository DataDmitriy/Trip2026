// screens2.jsx — Days, Chat, Route, Flights, Baggage, Budget

const { useState: useState2, useEffect: useEffect2, useRef: useRef2, useMemo: useMemo2 } = React;

// =================== DAYS / DIARY ===================

function DaysScreen({ onPlace }) {
  const cities = window.TRIP.cities;
  const allDays = [];
  cities.forEach(c => {
    (window.TRIP[c.id].days || []).forEach(d => allDays.push({ ...d, cityId: c.id, cityName: c.name, cityColor: c.color }));
  });

  const todayIdx = 6; // pretend day 7 (May 12) is today
  const [activeIdx, setActiveIdx] = useState2(todayIdx);

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <ScreenHeader
        title="Дневник по дням"
        subtitle="6 мая → 22 мая · 16 дней"
        large
        right={[<button key="s" style={iconBtn}><Ic.search s={22}/></button>]}
      />

      {/* Timeline strip */}
      <div style={{ overflowX: 'auto', padding: '4px 16px 12px' }} className="nsb">
        <div style={{ display: 'flex', gap: 8 }}>
          {allDays.map((d, i) => {
            const on = i === activeIdx;
            return (
              <button key={i} onClick={() => setActiveIdx(i)} style={{
                flexShrink: 0,
                background: on ? d.cityColor : 'var(--surface)',
                color: on ? '#fff' : 'var(--text)',
                border: `1px solid ${on ? d.cityColor : 'var(--border)'}`,
                borderTop: `3px solid ${d.cityColor}`,
                borderRadius: 14, padding: '8px 12px',
                cursor: 'pointer', minWidth: 92,
                fontFamily: '"Google Sans Text", sans-serif',
                textAlign: 'left',
              }}>
                <div style={{ fontSize: 10, opacity: 0.85, fontWeight: 600, letterSpacing: 0.4, textTransform: 'uppercase' }}>День {i+1}</div>
                <div style={{ fontSize: 13, fontWeight: 600, marginTop: 2 }}>{d.date.split(',')[0]}</div>
                <div style={{ fontSize: 11, opacity: 0.85, marginTop: 1 }}>{d.cityName}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Day detail */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 16px 24px' }} className="nsb">
        {allDays[activeIdx] && <DayDetail day={allDays[activeIdx]} onPlace={onPlace} />}
      </div>
    </div>
  );
}

function DayDetail({ day, onPlace }) {
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 4, marginBottom: 14 }}>
        <div style={{ fontSize: 22, fontWeight: 600, color: 'var(--text)', fontFamily: '"Google Sans", sans-serif' }}>{day.date}</div>
        <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>· {day.label}</div>
      </div>

      {/* Schedule */}
      <div style={{ position: 'relative' }}>
        <div style={{ position: 'absolute', left: 38, top: 14, bottom: 14, width: 1.5, background: 'var(--border-strong)' }} />
        {day.items.map((it, i) => (
          <ScheduleItem key={i} item={it} onPlace={onPlace} cityId={day.cityId} />
        ))}
      </div>
    </div>
  );
}

function ScheduleItem({ item, onPlace, cityId }) {
  const kindMeta = {
    flight: { color: '#3B82F6', icon: <Ic.flight s={16} />, label: 'Перелёт' },
    taxi: { color: '#F59E0B', icon: <Ic.car s={16} />, label: 'Такси' },
    transit: { color: '#8B5CF6', icon: <Ic.train s={16} />, label: 'Транспорт' },
    walk: { color: '#10B981', icon: <Ic.walk s={16} />, label: 'Прогулка' },
    rest: { color: '#737373', icon: <Ic.bed s={16} />, label: 'Жильё' },
    nap: { color: '#6366F1', icon: <Ic.moon s={16} />, label: 'Сон Лёвы' },
    food: { color: '#10B981', icon: '🍽', label: 'Еда' },
    place: { color: '#F06B50', icon: '📍', label: 'Место' },
  };
  const m = kindMeta[item.kind] || kindMeta.place;
  const isNap = item.kind === 'nap';
  const place = item.placeId ? window.TRIP[cityId].places.find(p => p.id === item.placeId) : null;

  return (
    <div style={{ display: 'flex', gap: 14, padding: '8px 0', alignItems: 'flex-start' }}>
      <div style={{ width: 52, fontSize: 13, fontWeight: 600, color: 'var(--text)', fontFamily: 'JetBrains Mono, monospace', paddingTop: 8 }}>
        {item.time}
      </div>
      <div style={{
        width: 32, height: 32, borderRadius: 16, flexShrink: 0,
        background: m.color, color: '#fff',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        zIndex: 1, fontSize: 14,
      }}>{m.icon}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div onClick={() => place && onPlace(place, window.TRIP.cities.find(c => c.id === cityId))} style={{
          background: isNap ? 'linear-gradient(135deg, #EEF0FF, #E5E9FF)' : 'var(--surface)',
          border: `1px solid ${isNap ? '#6366F133' : 'var(--border)'}`,
          borderRadius: 14, padding: '10px 14px',
          cursor: place ? 'pointer' : 'default',
        }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: m.color, textTransform: 'uppercase', letterSpacing: 0.4 }}>{m.label}</div>
          <div style={{ fontSize: 14, color: 'var(--text)', marginTop: 2, fontFamily: '"Google Sans Text", sans-serif' }}>{item.text}</div>
          {isNap && <div style={{ fontSize: 11, color: '#6366F1', marginTop: 4, fontWeight: 500 }}>⛔ Без транзита, без шоппинга — только дома</div>}
        </div>
      </div>
    </div>
  );
}

// =================== AI CHAT ===================

function ChatScreen({ initialContext }) {
  const seed = initialContext?.place
    ? [{ role: 'ai', text: `Открыта карточка «${initialContext.place.name}». Чем помочь? Например: «Чем заменить если идёт дождь?» или «Как уложиться до сна?»` }]
    : initialContext?.city
    ? [{ role: 'ai', text: `Я знаю расписание на ${initialContext.city.name}. Спросите: «Куда пойти сейчас?», «Где покормить детей быстро?» или «Что закрыто на этой неделе?»` }]
    : [
        { role: 'ai', text: 'Здравствуйте! Я ваш помощник по поездке. Знаю всё про маршрут Будапешт → Париж → Биллунн → Амстердам.' },
      ];
  const [msgs, setMsgs] = useState2(seed);
  const [input, setInput] = useState2('');
  const [thinking, setThinking] = useState2(false);
  const scrollRef = useRef2(null);

  useEffect2(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [msgs, thinking]);

  const prompts = initialContext?.city ? [
    `Что делать в ${initialContext.city.name} прямо сейчас?`,
    'Какое место ближе всего?',
    'Чем заменить, если дождь?',
    'Как уложиться до 12:45?',
  ] : [
    '🗺 Что делать сейчас?',
    '👶 Где быстрее всего покормить детей?',
    '⏰ Хватит ли времени до сна Лёвы?',
    '✈️ Что я знаю про следующий перелёт?',
  ];

  const send = (text) => {
    if (!text.trim()) return;
    const userMsg = { role: 'user', text };
    setMsgs(m => [...m, userMsg]);
    setInput('');
    setThinking(true);

    // Canned context-aware reply
    setTimeout(() => {
      setMsgs(m => [...m, generateReply(text, initialContext)]);
      setThinking(false);
    }, 900);
  };

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <ScreenHeader
        title="AI помощник"
        subtitle="Знает ваш маршрут, режим и детей"
        large
        right={[<button key="m" style={iconBtn}><Ic.more s={22}/></button>]}
      />

      <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', padding: '0 16px 16px' }} className="nsb">
        {msgs.map((m, i) => <ChatMsg key={i} msg={m} />)}
        {thinking && <ChatMsg msg={{ role: 'ai', text: '...', thinking: true }} />}

        {msgs.length === 1 && (
          <div style={{ marginTop: 14 }}>
            <div style={{ fontSize: 12, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: 0.4, fontWeight: 600, marginBottom: 8 }}>Начните с</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {prompts.map((p, i) => (
                <button key={i} onClick={() => send(p)} style={{
                  background: 'var(--surface)', border: '1px solid var(--border)',
                  borderRadius: 16, padding: '12px 16px', textAlign: 'left',
                  cursor: 'pointer', fontSize: 14, color: 'var(--text)',
                  fontFamily: '"Google Sans Text", sans-serif',
                }}>{p}</button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Input */}
      <div style={{ padding: '8px 12px 12px' }}>
        <div style={{
          display: 'flex', alignItems: 'flex-end', gap: 8,
          background: 'var(--surface)', border: '1px solid var(--border)',
          borderRadius: 24, padding: '6px 6px 6px 16px',
        }}>
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && send(input)}
            placeholder="Спросите что угодно про поездку..."
            style={{
              flex: 1, border: 'none', outline: 'none', background: 'transparent',
              fontSize: 15, color: 'var(--text)', padding: '10px 0',
              fontFamily: '"Google Sans Text", sans-serif',
            }}
          />
          <button onClick={() => send(input)} disabled={!input.trim()} style={{
            width: 40, height: 40, borderRadius: '50%',
            background: input.trim() ? 'var(--coral-btn)' : 'var(--border-strong)',
            border: 'none', cursor: input.trim() ? 'pointer' : 'default',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: '#fff',
          }}><Ic.send s={18}/></button>
        </div>
      </div>
    </div>
  );
}

function ChatMsg({ msg }) {
  const isAi = msg.role === 'ai';
  return (
    <div style={{ display: 'flex', gap: 10, marginTop: 14, alignItems: 'flex-start', justifyContent: isAi ? 'flex-start' : 'flex-end' }}>
      {isAi && (
        <div style={{
          width: 32, height: 32, borderRadius: '50%', background: 'var(--coral-text)',
          color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        }}><Ic.spark s={16}/></div>
      )}
      <div style={{
        background: isAi ? 'var(--surface)' : 'var(--coral-text)',
        color: isAi ? 'var(--text)' : '#fff',
        border: isAi ? '1px solid var(--border)' : 'none',
        borderRadius: isAi ? '4px 16px 16px 16px' : '16px 4px 16px 16px',
        padding: '10px 14px', fontSize: 14, lineHeight: 1.5,
        maxWidth: '78%',
        fontFamily: '"Google Sans Text", sans-serif',
        whiteSpace: 'pre-wrap',
      }}>
        {msg.thinking ? (
          <div style={{ display: 'flex', gap: 4 }}>
            {[0,1,2].map(i => <span key={i} style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--text-secondary)', animation: `bounce 1.2s ${i*0.15}s infinite` }} />)}
            <style>{`@keyframes bounce { 0%, 80%, 100% { opacity: 0.3; transform: translateY(0); } 40% { opacity: 1; transform: translateY(-3px); } }`}</style>
          </div>
        ) : msg.text}
        {msg.suggestions && (
          <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 6 }}>
            {msg.suggestions.map((s, i) => (
              <div key={i} style={{ background: '#fff', color: '#111', borderRadius: 10, padding: '8px 12px', fontSize: 13, border: '1px solid #00000010' }}>
                <div style={{ fontWeight: 600 }}>{s.title}</div>
                {s.subtitle && <div style={{ fontSize: 12, color: '#555', marginTop: 2 }}>{s.subtitle}</div>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function generateReply(text, ctx) {
  const t = text.toLowerCase();
  if (t.includes('сейчас') || t.includes('куда') || t.includes('что делать')) {
    return {
      role: 'ai',
      text: `Сейчас 11:14, среда. До сна Лёвы 1ч 46мин — успеете ОДНУ короткую активность плюс обед.\n\nВ 5 минутах от Adagio Serris:`,
      suggestions: [
        { title: '🏰 Fantasyland — Карусель Ланселота', subtitle: '8 мин на шаттле, очередь сейчас 15 мин' },
        { title: '🛍 Val d\'Europe ТЦ + Aquarium', subtitle: '5 мин пешком, тише, есть еда' },
      ],
    };
  }
  if (t.includes('дожд') || t.includes('замен') || t.includes('погод')) {
    return { role: 'ai', text: 'Если идёт дождь, лучшие крытые опции: \n\n• Lego House (если в Биллунне) — 6 часов в крытом 4-этажном здании\n• Aquadome в Lalandia — крытый аквапарк\n• MiniPolisz в Будапеште — игровой город\n• ТЦ Val d\'Europe в Серрисе — есть аквариум, рестораны, играет на 2-3 часа.' };
  }
  if (t.includes('покорм') || t.includes('ед') || t.includes('голодн') || t.includes('обед')) {
    return {
      role: 'ai',
      text: 'Для быстрого обеда с детьми (без бронирования, фастер чем 30 минут):',
      suggestions: [
        { title: '🍲 Gettó Gulyás (Будапешт)', subtitle: '300 м от жилья, гуляш за 12 минут' },
        { title: '🍕 Earl of Sandwich (Disney Village)', subtitle: 'Нет очередей до 11:45' },
        { title: '🥨 Lalandia Food Court', subtitle: 'В курорте, не надо никуда ехать' },
      ],
    };
  }
  if (t.includes('сон') || t.includes('лёв') || t.includes('12:45') || t.includes('успеть')) {
    return { role: 'ai', text: 'Главное правило режима Лёвы: возврат в апартаменты не позже 12:45. От любой точки маршрута сейчас:\n\n• Disneyland Park → Adagio Serris: шаттл 8 мин\n• Walt Disney Studios → Adagio Serris: шаттл 10 мин\n• Val d\'Europe → апартаменты: 5 мин пешком\n\nЕсли последняя активность не уложится в 12:00 — лучше отменить и заменить на тихую прогулку.' };
  }
  if (t.includes('перелёт') || t.includes('перелет') || t.includes('самолёт') || t.includes('следующий')) {
    return { role: 'ai', text: 'Следующий перелёт: 16 мая, Air France CDG → BLL.\n\n• Вылет ~13:00 (КОНФЛИКТ со сном!) — продумайте перенос.\n• Длительность 1ч 45м.\n• Аэропорт BLL примыкает к Леголенду — 5 минут на такси до Lalandia.\n• На каждого пассажира 1 чемодан 23 кг + ручная кладь. Достаточно с запасом.' };
  }
  if (t.includes('ближ') || t.includes('рядом')) {
    return { role: 'ai', text: 'В радиусе 1 км от вашего жилья:\n\n• 🍲 Gettó Gulyás — 300 м\n• 🍷 Fülemüle — 450 м\n• 🍽 VakVarjú — 600 м\n• 🏙 MiniPolisz — 450 м\n• 🦴 Музей естествознания — 1.6 км (трамвай)\n\nВсё остальное — 1.5 км+, нужен транспорт.' };
  }
  return { role: 'ai', text: 'Хороший вопрос. Я учёл режим сна Лёвы (13:00–15:00), отсутствие коляски и багаж. Уточните город или конкретное место — дам точный ответ.' };
}

// =================== ROUTE / DIRECTIONS ===================

function RouteScreen({ place, city, onBack, dark }) {
  const cityData = window.TRIP[city.id];
  const stay = cityData.stay;

  // Synthesize a 3-step plan
  const steps = useMemo2(() => {
    if (place.dist?.includes('пешком') || place.dist?.includes('м · ')) {
      const m = place.dist.match(/(\d+)\s*м/);
      const meters = m ? +m[1] : 500;
      return [
        { kind: 'walk', dur: Math.round(meters / 80), dist: `${meters} м`, label: `Пешком от ${stay.name}`, color: '#10B981' },
      ];
    }
    if (place.dist?.includes('M3') || place.dist?.includes('M2') || place.dist?.includes('метро')) {
      return [
        { kind: 'walk', dur: 5, dist: '350 м', label: `Пешком до метро ${stay.metro}`, color: '#10B981' },
        { kind: 'train', dur: 22, dist: '7 ост.', label: `Метро M3 → ${place.dist.split(' до ')[1] || place.name}`, color: '#8B5CF6' },
        { kind: 'walk', dur: 4, dist: '280 м', label: `Пешком до ${place.name}`, color: '#10B981' },
      ];
    }
    if (place.dist?.includes('автобус')) {
      return [
        { kind: 'walk', dur: 3, dist: '180 м', label: 'До остановки Astoria', color: '#10B981' },
        { kind: 'bus', dur: 7, dist: '4 ост.', label: 'Автобус 16 → Széchenyi tér', color: '#3B82F6' },
        { kind: 'walk', dur: 2, dist: '120 м', label: `До ${place.name}`, color: '#10B981' },
      ];
    }
    if (place.dist?.includes('шаттл')) {
      return [
        { kind: 'walk', dur: 2, dist: '120 м', label: 'До остановки шаттла', color: '#10B981' },
        { kind: 'bus', dur: 8, dist: 'прямой', label: 'Disney Shuttle → Park Gates', color: '#3B82F6' },
      ];
    }
    return [
      { kind: 'walk', dur: 3, dist: '200 м', label: 'Пешком до транспорта', color: '#10B981' },
      { kind: 'bus', dur: 10, dist: '5 ост.', label: 'Общественный транспорт', color: '#3B82F6' },
      { kind: 'walk', dur: 3, dist: '180 м', label: `До ${place.name}`, color: '#10B981' },
    ];
  }, [place.id]);

  const totalMin = steps.reduce((s, it) => s + it.dur, 0);

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <ScreenHeader title="Как добраться" onBack={onBack} />

      {/* Mini summary card */}
      <div style={{ padding: '0 16px 12px' }}>
        <Card style={{ background: 'linear-gradient(135deg, var(--coral-soft), var(--surface))' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <div style={{ fontSize: 32, fontWeight: 700, color: 'var(--text)', fontFamily: '"Google Sans", sans-serif' }}>{totalMin}</div>
            <div style={{ fontSize: 14, color: 'var(--text-secondary)', fontWeight: 500 }}>мин в пути</div>
            <div style={{ flex: 1 }} />
            <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>Прибытие ≈ {addMinutesToNow(totalMin)}</div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 12 }}>
            <div style={{ fontSize: 18 }}>🏠</div>
            <div style={{ flex: 1, height: 2, background: 'repeating-linear-gradient(to right, var(--border-strong) 0, var(--border-strong) 4px, transparent 4px, transparent 8px)' }} />
            <div style={{ fontSize: 18 }}>{place.emoji}</div>
          </div>
        </Card>
      </div>

      {/* Steps timeline */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 16px 100px' }} className="nsb">
        <SectionLabel>Шаги</SectionLabel>

        <div style={{ position: 'relative', paddingLeft: 4 }}>
          <RouteStartEnd label="Откуда" name={stay.name} sub={stay.addr} icon="🏠" />
          {steps.map((s, i) => <RouteStep key={i} step={s} />)}
          <RouteStartEnd label="Куда" name={place.name} sub={place.addr} icon={place.emoji} highlight />
        </div>

        {/* Family advice */}
        <div style={{ marginTop: 18 }}>
          <SectionLabel>Семейные нюансы</SectionLabel>
          <Card>
            <Adv icon="👶" text="Лёва (2г) проходит без жалоб ≤ 800 м. Маршрут уложился в лимит." good />
            <Adv icon="🎒" text="Пересадок: 0. С 5 единицами ручной клади это критично." good />
            <Adv icon="🌧" text="Прогноз: ясно, +18°. Лёгкая ветровка." />
            <Adv icon="💤" text={`До сна Лёвы 2 часа 14 мин — есть запас.`} good />
          </Card>
        </div>
      </div>

      {/* Sticky CTA */}
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: 16, background: 'linear-gradient(to top, var(--bg) 60%, transparent)' }}>
        <button style={{ ...ctaPrimary, width: '100%' }}>
          <Ic.navUp s={18}/> Запустить навигацию
        </button>
      </div>
    </div>
  );
}

function addMinutesToNow(m) {
  const base = new Date();
  base.setHours(11, 14, 0);
  base.setMinutes(base.getMinutes() + m);
  return `${base.getHours()}:${String(base.getMinutes()).padStart(2,'0')}`;
}

function RouteStartEnd({ label, name, sub, icon, highlight }) {
  return (
    <div style={{ display: 'flex', gap: 14, alignItems: 'center', padding: '12px 0' }}>
      <div style={{
        width: 40, height: 40, borderRadius: 12,
        background: highlight ? 'var(--coral-soft)' : 'var(--surface)',
        border: '1px solid var(--border)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22,
      }}>{icon}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 11, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: 0.5, fontWeight: 700 }}>{label}</div>
        <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--text)' }}>{name}</div>
        <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{sub}</div>
      </div>
    </div>
  );
}

function RouteStep({ step }) {
  const iconMap = { walk: <Ic.walk s={16}/>, bus: <Ic.bus s={16}/>, train: <Ic.train s={16}/>, car: <Ic.car s={16}/> };
  return (
    <div style={{ display: 'flex', gap: 14, alignItems: 'center', padding: '4px 0' }}>
      <div style={{ width: 40, display: 'flex', justifyContent: 'center' }}>
        <div style={{ width: 2, height: 32, background: step.color, borderRadius: 1 }} />
      </div>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 12 }}>
        <div style={{ width: 28, height: 28, borderRadius: '50%', background: step.color, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          {iconMap[step.kind]}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)' }}>{step.label}</div>
          <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{step.dist}</div>
        </div>
        <div style={{ fontSize: 13, fontWeight: 700, color: step.color, fontFamily: 'JetBrains Mono, monospace' }}>{step.dur} мин</div>
      </div>
    </div>
  );
}

function Adv({ icon, text, good }) {
  return (
    <div style={{ display: 'flex', gap: 10, padding: '6px 0', alignItems: 'flex-start' }}>
      <div style={{ fontSize: 16, width: 22 }}>{good ? '✅' : icon}</div>
      <div style={{ flex: 1, fontSize: 13, color: 'var(--text)', lineHeight: 1.4 }}>{text}</div>
    </div>
  );
}

// =================== FLIGHTS ===================

function FlightsScreen() {
  const flights = window.TRIP.flights;
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <ScreenHeader title="Перелёты и трансферы" subtitle="4 рейса · 1 чемодан · 5 ручных кладей" large />
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 16px 24px' }} className="nsb">
        {flights.map((f, i) => <FlightCard key={f.id} flight={f} idx={i+1} />)}

        <div style={{ marginTop: 16 }}>
          <SectionLabel>Багаж</SectionLabel>
          <Card>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)' }}>1 × Чемодан 23 кг</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>В трюм, KLM/Air France</div>
              </div>
              <div style={{ fontSize: 24 }}>🧳</div>
            </div>
            <div style={{ height: 1, background: 'var(--border)', margin: '12px 0' }} />
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)' }}>5 × Ручная кладь</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>По одной на каждого пассажира</div>
              </div>
              <div style={{ fontSize: 24 }}>🎒</div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function FlightCard({ flight, idx }) {
  return (
    <Card style={{ marginBottom: 12 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div style={{ fontSize: 11, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: 0.6, fontWeight: 700 }}>Перелёт {idx} · {flight.date}</div>
        <div style={{ fontSize: 11, color: 'var(--text-secondary)', fontFamily: 'JetBrains Mono, monospace' }}>{flight.code}</div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 10 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 28, fontWeight: 700, color: 'var(--text)', fontFamily: '"Google Sans", sans-serif', letterSpacing: '-0.5px' }}>{flight.from}</div>
          <div style={{ fontSize: 13, color: 'var(--text-secondary)', fontFamily: 'JetBrains Mono, monospace' }}>{flight.time}</div>
        </div>
        <div style={{ flex: 1.5, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <div style={{ fontSize: 11, color: 'var(--text-secondary)', fontWeight: 600 }}>{flight.dur}</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, width: '100%', margin: '4px 0' }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--text)' }} />
            <div style={{ flex: 1, height: 1, background: 'var(--border-strong)', position: 'relative' }}>
              <div style={{ position: 'absolute', top: -8, left: '50%', transform: 'translateX(-50%)' }}><Ic.flight s={16} style={{ color: 'var(--coral-text)' }}/></div>
            </div>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--text)' }} />
          </div>
          <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{flight.airline}</div>
        </div>
        <div style={{ flex: 1, textAlign: 'right' }}>
          <div style={{ fontSize: 28, fontWeight: 700, color: 'var(--text)', fontFamily: '"Google Sans", sans-serif', letterSpacing: '-0.5px' }}>{flight.to}</div>
          <div style={{ fontSize: 13, color: 'var(--text-secondary)', fontFamily: 'JetBrains Mono, monospace' }}>{flight.date}</div>
        </div>
      </div>

      {flight.tip && (
        <div style={{ marginTop: 10, padding: '8px 12px', background: 'var(--coral-soft)', borderRadius: 10, fontSize: 12, color: 'var(--text)', display: 'flex', gap: 8 }}>
          <span>💡</span>
          <span style={{ flex: 1 }}>{flight.tip}</span>
        </div>
      )}
    </Card>
  );
}

// =================== BAGGAGE / CHECKLIST ===================

function BaggageScreen() {
  const [groups, setGroups] = useState2(window.TRIP.baggage);
  const toggle = (gi, ii) => {
    setGroups(g => g.map((gr, i) => i !== gi ? gr : ({ ...gr, items: gr.items.map((it, j) => j !== ii ? it : ({ ...it, done: !it.done })) })));
  };
  const totalDone = groups.reduce((s, g) => s + g.items.filter(i => i.done).length, 0);
  const total = groups.reduce((s, g) => s + g.items.length, 0);

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <ScreenHeader title="Багаж и документы" subtitle={`${totalDone} из ${total} собрано`} large />
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 16px 24px' }} className="nsb">

        {/* Progress */}
        <Card style={{ marginBottom: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ width: 56, height: 56, borderRadius: '50%', background: `conic-gradient(var(--coral-text) ${(totalDone/total)*360}deg, var(--border) 0)`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <div style={{ width: 44, height: 44, borderRadius: '50%', background: 'var(--surface)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700, color: 'var(--text)', fontFamily: 'JetBrains Mono, monospace' }}>{Math.round(totalDone/total*100)}%</div>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)' }}>До вылета 6 дней</div>
              <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>Не забудьте проверить срок паспортов</div>
            </div>
          </div>
        </Card>

        {groups.map((g, gi) => (
          <div key={g.id} style={{ marginBottom: 16 }}>
            <SectionLabel>{g.label}</SectionLabel>
            <Card style={{ padding: 6 }}>
              {g.items.map((it, ii) => (
                <div key={ii} onClick={() => toggle(gi, ii)} style={{
                  display: 'flex', alignItems: 'center', gap: 12,
                  padding: '10px 10px', cursor: 'pointer',
                  borderBottom: ii < g.items.length - 1 ? '1px solid var(--border)' : 'none',
                }}>
                  <div style={{
                    width: 22, height: 22, borderRadius: 6,
                    background: it.done ? 'var(--coral-text)' : 'transparent',
                    border: `2px solid ${it.done ? 'var(--coral-text)' : 'var(--border-strong)'}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    color: '#fff', flexShrink: 0,
                  }}>{it.done && <Ic.check s={14}/>}</div>
                  <div style={{ flex: 1, fontSize: 14, color: 'var(--text)', textDecoration: it.done ? 'line-through' : 'none', opacity: it.done ? 0.5 : 1 }}>{it.t}</div>
                </div>
              ))}
            </Card>
          </div>
        ))}
      </div>
    </div>
  );
}

// =================== BUDGET ===================

function BudgetScreen() {
  const b = window.TRIP.budget;
  const pct = Math.round((b.spent / b.total) * 100);
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <ScreenHeader title="Бюджет" subtitle="Семейная поездка · май 2026" large />
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 16px 24px' }} className="nsb">

        {/* Big number */}
        <Card style={{ marginBottom: 14, padding: 20 }}>
          <div style={{ fontSize: 11, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: 0.5, fontWeight: 700 }}>Потрачено / план</div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 6 }}>
            <div style={{ fontSize: 40, fontWeight: 700, color: 'var(--text)', fontFamily: 'JetBrains Mono, monospace', letterSpacing: '-1px' }}>{b.currency}{b.spent.toLocaleString('ru')}</div>
            <div style={{ fontSize: 16, color: 'var(--text-secondary)', fontFamily: 'JetBrains Mono, monospace' }}>/ {b.currency}{b.total.toLocaleString('ru')}</div>
          </div>
          {/* Bar */}
          <div style={{ height: 10, background: 'var(--border)', borderRadius: 5, overflow: 'hidden', marginTop: 14, display: 'flex' }}>
            {b.cats.map((c, i) => (
              <div key={i} style={{ width: `${(c.spent/b.total)*100}%`, background: c.color }} />
            ))}
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8, fontSize: 12, color: 'var(--text-secondary)' }}>
            <span>{pct}% потрачено</span>
            <span>{b.currency}{(b.total-b.spent).toLocaleString('ru')} осталось</span>
          </div>
        </Card>

        <SectionLabel>Категории</SectionLabel>
        {b.cats.map(c => (
          <Card key={c.name} style={{ marginBottom: 10 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 10, height: 38, borderRadius: 5, background: c.color }} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)' }}>{c.name}</div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)', fontFamily: 'JetBrains Mono, monospace' }}>{c.spent === c.plan ? '✓' : ''} {b.currency}{c.spent}<span style={{ color: 'var(--text-secondary)', fontWeight: 400 }}> / {c.plan}</span></div>
                </div>
                <div style={{ height: 4, background: 'var(--border)', borderRadius: 2, marginTop: 6 }}>
                  <div style={{ width: `${(c.spent/c.plan)*100}%`, height: '100%', background: c.color, borderRadius: 2 }} />
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

// =================== MORE MENU ===================

function MoreScreen({ go }) {
  const items = [
    { id: 'baggage', icon: Ic.bag, label: 'Багаж и документы', sub: 'Чек-лист на 16 дней' },
    { id: 'budget', icon: Ic.euro, label: 'Бюджет', sub: '€5 210 из €8 400' },
    { id: 'filters', icon: Ic.filter, label: 'Детские фильтры', sub: 'Возраст, дистанция, сон' },
    { id: 'family', icon: Ic.bed, label: 'Семья', sub: '2 + 3 (2, 5, 6 лет)' },
    { id: 'settings', icon: Ic.device, label: 'Настройки', sub: 'Тема, устройство, язык' },
  ];
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <ScreenHeader title="Ещё" large subtitle="Trip 2026 · Семейный помощник" />
      <div style={{ flex: 1, overflowY: 'auto', padding: '4px 16px 24px' }} className="nsb">
        {items.map(it => (
          <div key={it.id} onClick={() => go(it.id)} style={{
            display: 'flex', alignItems: 'center', gap: 14,
            padding: '14px 14px', cursor: 'pointer',
            background: 'var(--surface)', border: '1px solid var(--border)',
            borderRadius: 14, marginBottom: 8,
          }}>
            <div style={{ width: 40, height: 40, borderRadius: 10, background: 'var(--coral-soft)', color: 'var(--coral-text)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><it.icon s={20}/></div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--text)' }}>{it.label}</div>
              <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{it.sub}</div>
            </div>
            <div style={{ color: 'var(--text-secondary)' }}>→</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// =================== KIDS FILTERS ===================

function FiltersScreen({ onBack }) {
  const [age, setAge] = useState2(2);
  const [dist, setDist] = useState2(1);
  const [napAware, setNapAware] = useState2(true);
  const [openNow, setOpenNow] = useState2(true);

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <ScreenHeader title="Детские фильтры" onBack={onBack} />
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px 24px' }} className="nsb">
        <SectionLabel>Возраст самого младшего</SectionLabel>
        <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
          {[2,3,5,6].map(a => (
            <button key={a} onClick={() => setAge(a)} style={{
              flex: 1, padding: '12px 0',
              border: `1.5px solid ${age === a ? 'var(--coral-text)' : 'var(--border-strong)'}`,
              background: age === a ? 'var(--coral-soft)' : 'var(--surface)',
              color: age === a ? 'var(--coral-text)' : 'var(--text)',
              borderRadius: 12, fontSize: 14, fontWeight: 600, cursor: 'pointer',
              fontFamily: '"Google Sans Text", sans-serif',
            }}>{a} {a === 2 ? 'г' : 'лет'}</button>
          ))}
        </div>

        <SectionLabel>Максимум пешком до места</SectionLabel>
        <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 14, padding: 14, marginBottom: 18 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 8 }}>
            <span style={{ fontSize: 14, fontWeight: 500, color: 'var(--text)' }}>Дистанция</span>
            <span style={{ fontSize: 18, fontWeight: 700, color: 'var(--coral-text)', fontFamily: 'JetBrains Mono, monospace' }}>{dist < 1 ? `${(dist*1000).toFixed(0)} м` : `${dist.toFixed(1)} км`}</span>
          </div>
          <input type="range" min={0.3} max={3} step={0.1} value={dist} onChange={e => setDist(+e.target.value)} style={{ width: '100%', accentColor: 'var(--coral-text)' }} />
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--text-secondary)', marginTop: 4 }}><span>300 м</span><span>3 км</span></div>
        </div>

        <SectionLabel>Условия</SectionLabel>
        <Toggle label="Учитывать сон Лёвы (13:00–15:00)" sub="Не показывать места дальше 30 мин в это окно" on={napAware} onChange={setNapAware} />
        <Toggle label="Только открытые сейчас" sub="С учётом часов работы" on={openNow} onChange={setOpenNow} />
        <Toggle label="С детским меню или игровой" sub="Только в категории «еда»" on={true} onChange={() => {}} />
        <Toggle label="Без многоступенчатых пересадок" sub="С 5 ручными кладями" on={true} onChange={() => {}} />

        <button style={{ ...ctaPrimary, width: '100%', marginTop: 16 }}>Применить фильтры</button>
      </div>
    </div>
  );
}

function Toggle({ label, sub, on, onChange }) {
  return (
    <div onClick={() => onChange(!on)} style={{
      display: 'flex', gap: 12, alignItems: 'center', padding: '14px',
      background: 'var(--surface)', border: '1px solid var(--border)',
      borderRadius: 14, marginBottom: 8, cursor: 'pointer',
    }}>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--text)' }}>{label}</div>
        {sub && <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 2 }}>{sub}</div>}
      </div>
      <div style={{
        width: 44, height: 26, borderRadius: 13,
        background: on ? 'var(--coral-text)' : 'var(--border-strong)',
        position: 'relative', transition: 'background 0.15s',
        flexShrink: 0,
      }}>
        <div style={{
          position: 'absolute', top: 3, left: on ? 21 : 3,
          width: 20, height: 20, borderRadius: '50%', background: '#fff',
          transition: 'left 0.15s', boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
        }} />
      </div>
    </div>
  );
}

Object.assign(window, {
  DaysScreen, ChatScreen, RouteScreen, FlightsScreen, BaggageScreen, BudgetScreen, MoreScreen, FiltersScreen, Toggle,
});
