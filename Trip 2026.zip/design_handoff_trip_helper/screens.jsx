// screens.jsx — All screen components

const { useState, useEffect, useRef, useMemo } = React;

// =================== SHARED PRIMITIVES ===================

function Chip({ active, onClick, children, color }) {
  return (
    <button onClick={onClick} style={{
      border: 'none', cursor: 'pointer',
      padding: '8px 14px', borderRadius: 100,
      background: active ? (color || '#1f1f1f') : 'var(--chip-bg)',
      color: active ? '#fff' : 'var(--text)',
      fontSize: 13, fontWeight: 500,
      fontFamily: '"Google Sans Text", sans-serif',
      whiteSpace: 'nowrap',
      transition: 'all 0.15s ease',
    }}>{children}</button>
  );
}

function Card({ children, onClick, style, accent }) {
  return (
    <div onClick={onClick} style={{
      background: 'var(--surface)',
      borderRadius: 20,
      padding: 16,
      border: '1px solid var(--border)',
      cursor: onClick ? 'pointer' : 'default',
      borderTop: accent ? `3px solid ${accent}` : undefined,
      ...style,
    }}>{children}</div>
  );
}

function ScreenHeader({ title, subtitle, onBack, right, large = false }) {
  return (
    <div style={{ padding: '8px 20px 12px', flexShrink: 0 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, height: 48 }}>
        {onBack && (
          <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 8, marginLeft: -8, color: 'var(--text)', display: 'flex' }}>
            <Ic.back s={22}/>
          </button>
        )}
        {!large && <div style={{ flex: 1, fontSize: 20, fontWeight: 600, color: 'var(--text)', fontFamily: '"Google Sans", sans-serif' }}>{title}</div>}
        {large && <div style={{ flex: 1 }} />}
        <div style={{ display: 'flex', gap: 4 }}>{right}</div>
      </div>
      {large && (
        <div style={{ marginTop: 4 }}>
          <div style={{ fontSize: 28, fontWeight: 600, color: 'var(--text)', letterSpacing: '-0.5px', fontFamily: '"Google Sans", sans-serif', lineHeight: 1.2 }}>{title}</div>
          {subtitle && <div style={{ fontSize: 14, color: 'var(--text-secondary)', marginTop: 4 }}>{subtitle}</div>}
        </div>
      )}
    </div>
  );
}

function BottomNav({ active, onChange }) {
  const items = [
    { id: 'map', icon: Ic.map, label: 'Карта' },
    { id: 'days', icon: Ic.cal, label: 'По дням' },
    { id: 'chat', icon: Ic.chat, label: 'AI помощник' },
    { id: 'flights', icon: Ic.flight, label: 'Перелёты' },
    { id: 'more', icon: Ic.more, label: 'Ещё' },
  ];
  return (
    <div style={{
      flexShrink: 0,
      background: 'var(--bg)',
      borderTop: '1px solid var(--border)',
      paddingBottom: 6, paddingTop: 4,
      display: 'flex',
    }}>
      {items.map(it => {
        const on = active === it.id;
        return (
          <button key={it.id} onClick={() => onChange(it.id)} style={{
            flex: 1, background: 'none', border: 'none', cursor: 'pointer',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
            padding: '6px 0',
            color: on ? 'var(--coral-text)' : 'var(--text-secondary)',
            fontFamily: '"Google Sans Text", sans-serif',
          }}>
            <div style={{
              padding: '4px 18px',
              borderRadius: 16,
              background: on ? 'var(--coral-soft)' : 'transparent',
              transition: 'background 0.15s',
            }}>
              <it.icon s={22} />
            </div>
            <span style={{ fontSize: 11, fontWeight: on ? 600 : 500 }}>{it.label}</span>
          </button>
        );
      })}
    </div>
  );
}

// =================== HOME / EUROPE MAP ===================

function HomeMapScreen({ onCity, onPlace, dark, setStage }) {
  const [activeCity, setActiveCity] = useState(null);
  const cities = window.TRIP.cities;
  const today = useMemo(() => {
    // Pretend today is 12 May 2026 → Disneyland day
    return cities[1];
  }, []);

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Header on top of map */}
      <div style={{
        position: 'absolute', top: 8, left: 12, right: 12, zIndex: 10,
        display: 'flex', gap: 10, alignItems: 'center',
      }}>
        <div style={{
          flex: 1, height: 48, borderRadius: 24,
          background: 'var(--surface)', border: '1px solid var(--border)',
          display: 'flex', alignItems: 'center', padding: '0 16px', gap: 12,
          boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
        }}>
          <Ic.search s={20} style={{ color: 'var(--text-secondary)' }} />
          <span style={{ flex: 1, fontSize: 15, color: 'var(--text-secondary)', fontFamily: '"Google Sans Text", sans-serif' }}>Куда сейчас?</span>
          <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'var(--coral-text)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 600 }}>А</div>
        </div>
      </div>

      {/* Europe map full bleed */}
      <div style={{ flex: 1, position: 'relative' }}>
        <EuropeMap
          cities={cities}
          activeId={activeCity?.id}
          onCity={c => setActiveCity(c)}
          dark={dark}
        />

        {/* Floating "today" badge top-right */}
        <div style={{ position: 'absolute', top: 70, right: 12, zIndex: 9 }}>
          <button onClick={() => onCity(today)} style={{
            background: 'var(--coral-btn)', color: '#fff', border: 'none', cursor: 'pointer',
            padding: '8px 14px', borderRadius: 20,
            display: 'flex', alignItems: 'center', gap: 6,
            fontSize: 13, fontWeight: 600,
            fontFamily: '"Google Sans Text", sans-serif',
            boxShadow: '0 4px 16px rgba(240,107,80,0.4)',
          }}>
            <span>📍</span>
            Сейчас: {today.name}
          </button>
        </div>

        {/* Floating action buttons */}
        <div style={{ position: 'absolute', right: 14, bottom: 200, display: 'flex', flexDirection: 'column', gap: 10, zIndex: 9 }}>
          <FAB><Ic.filter s={20}/></FAB>
          <FAB><Ic.navUp s={20}/></FAB>
        </div>
      </div>

      {/* Bottom sheet: cities list */}
      <div style={{
        flexShrink: 0,
        background: 'var(--bg)',
        borderTopLeftRadius: 28, borderTopRightRadius: 28,
        boxShadow: '0 -2px 24px rgba(0,0,0,0.1)',
        padding: '8px 0 12px',
        zIndex: 5,
      }}>
        <div style={{ width: 36, height: 4, background: 'var(--border-strong)', borderRadius: 2, margin: '0 auto 12px' }} />
        <div style={{ padding: '0 20px 8px', display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
          <div style={{ fontSize: 20, fontWeight: 600, fontFamily: '"Google Sans", sans-serif', color: 'var(--text)' }}>Этапы маршрута</div>
          <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>16 дней · 4 страны</div>
        </div>
        <div style={{ display: 'flex', gap: 12, padding: '4px 20px 4px', overflowX: 'auto' }} className="nsb">
          {cities.map((c, i) => {
            const isActive = activeCity?.id === c.id;
            const isTodayCity = today.id === c.id;
            return (
              <div key={c.id} onClick={() => onCity(c)} style={{
                flexShrink: 0, width: 168,
                background: isActive ? c.color : 'var(--surface)',
                color: isActive ? '#fff' : 'var(--text)',
                border: `1px solid ${isActive ? c.color : 'var(--border)'}`,
                borderTop: `3px solid ${c.color}`,
                borderRadius: 16, padding: 14,
                cursor: 'pointer',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                  <div style={{ fontSize: 11, fontWeight: 600, opacity: 0.8, letterSpacing: 0.4, textTransform: 'uppercase' }}>Этап {i+1}</div>
                  {isTodayCity && <div style={{ background: '#fff', color: c.color, fontSize: 9, fontWeight: 700, padding: '2px 6px', borderRadius: 4 }}>СЕЙЧАС</div>}
                </div>
                <div style={{ fontSize: 18, fontWeight: 600, fontFamily: '"Google Sans", sans-serif' }}>{c.name}</div>
                <div style={{ fontSize: 12, opacity: 0.85, marginTop: 2 }}>{c.country}</div>
                <div style={{ fontSize: 12, marginTop: 8, opacity: 0.85, fontFamily: 'JetBrains Mono, monospace' }}>{c.dates}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function FAB({ children, onClick }) {
  return (
    <button onClick={onClick} style={{
      width: 44, height: 44, borderRadius: '50%',
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
      cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: 'var(--text)',
    }}>{children}</button>
  );
}

// =================== CITY DETAIL ===================

function CityScreen({ city, onBack, onPlace, dark, onChat }) {
  const cityData = window.TRIP[city.id];
  const [filter, setFilter] = useState('all');
  const [focusId, setFocusId] = useState(null);
  const places = cityData.places;
  const filtered = filter === 'all' ? places : places.filter(p => p.tag === filter);

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <ScreenHeader
        title={city.name}
        subtitle={`${city.country} · ${city.dates}`}
        onBack={onBack}
        large
        right={[
          <button key="s" style={iconBtn}><Ic.search s={22}/></button>,
          <button key="m" style={iconBtn}><Ic.more s={22}/></button>,
        ]}
      />

      {/* Hero map */}
      <div style={{ height: 220, position: 'relative', overflow: 'hidden', borderRadius: 24, margin: '0 16px' }}>
        <CityMap city={city} places={filtered} stay={cityData.stay} focusId={focusId} onPlace={p => { setFocusId(p.id); }} dark={dark} />
        {focusId && (
          <button onClick={() => onPlace(places.find(p => p.id === focusId), city)} style={{
            position: 'absolute', bottom: 12, left: 12, right: 12,
            background: 'var(--coral-btn)', color: '#fff', border: 'none',
            padding: '12px 16px', borderRadius: 14, cursor: 'pointer',
            fontSize: 14, fontWeight: 600,
            fontFamily: '"Google Sans Text", sans-serif',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            boxShadow: '0 4px 16px rgba(240,107,80,0.35)',
          }}>
            <span>Открыть {places.find(p => p.id === focusId)?.name}</span>
            <span>→</span>
          </button>
        )}
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 8, padding: '14px 20px 8px', overflowX: 'auto' }} className="nsb">
        <Chip active={filter === 'all'} onClick={() => setFilter('all')}>Всё ({places.length})</Chip>
        <Chip active={filter === 'wow'} onClick={() => setFilter('wow')} color="#F06B50">🤩 Главное</Chip>
        <Chip active={filter === 'kids'} onClick={() => setFilter('kids')} color="#3B82F6">🧸 Для детей</Chip>
        <Chip active={filter === 'science'} onClick={() => setFilter('science')} color="#8B5CF6">🔬 Наука</Chip>
        <Chip active={filter === 'food'} onClick={() => setFilter('food')} color="#10B981">🍽 Еда</Chip>
      </div>

      {/* Places list */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '4px 16px 80px' }} className="nsb">
        {/* Stay card */}
        <Card style={{ marginBottom: 12 }} accent="#F06B50">
          <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: 'var(--coral-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>🏠</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: 0.4, fontWeight: 600 }}>Жильё</div>
              <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--text)' }}>{cityData.stay.name}</div>
              <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{cityData.stay.addr} · {cityData.stay.metro}</div>
            </div>
          </div>
        </Card>

        {filtered.map(p => <PlaceListItem key={p.id} place={p} onClick={() => onPlace(p, city)} />)}

        {/* AI prompt nudge */}
        <button onClick={() => onChat({ city })} style={{
          width: '100%', marginTop: 8,
          background: 'var(--surface)', border: '1px dashed var(--border-strong)',
          borderRadius: 16, padding: 14,
          display: 'flex', gap: 12, alignItems: 'center',
          cursor: 'pointer', textAlign: 'left',
          fontFamily: '"Google Sans Text", sans-serif', color: 'var(--text)',
        }}>
          <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'var(--coral-text)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Ic.spark s={18} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 600 }}>Спросить помощника</div>
            <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>«Куда пойти прямо сейчас в {city.name}?»</div>
          </div>
        </button>
      </div>
    </div>
  );
}

function PlaceListItem({ place, onClick }) {
  const colorMap = { wow: '#F06B50', kids: '#3B82F6', science: '#8B5CF6', food: '#10B981' };
  const col = colorMap[place.tag] || '#737373';
  return (
    <Card onClick={onClick} style={{ marginBottom: 10 }}>
      <div style={{ display: 'flex', gap: 14 }}>
        <div style={{
          width: 56, height: 56, borderRadius: 14,
          background: `${col}22`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 28, flexShrink: 0,
        }}>{place.emoji}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text)', fontFamily: '"Google Sans", sans-serif' }}>{place.name}</div>
            {place.tag === 'wow' && <span style={{ background: '#F06B5022', color: '#C84F38', fontSize: 10, fontWeight: 700, padding: '2px 6px', borderRadius: 4, letterSpacing: 0.4 }}>MUST</span>}
          </div>
          <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 2 }}>{place.subtitle}</div>
          <div style={{ display: 'flex', gap: 10, marginTop: 8, flexWrap: 'wrap' }}>
            <Meta icon="📍" text={place.dist} />
            <Meta icon="⏱" text={place.dur} />
            <Meta icon="👶" text={place.age} />
          </div>
        </div>
      </div>
    </Card>
  );
}

function Meta({ icon, text }) {
  return (
    <div style={{ fontSize: 11, color: 'var(--text-secondary)', display: 'inline-flex', alignItems: 'center', gap: 4 }}>
      <span>{icon}</span><span>{text}</span>
    </div>
  );
}

const iconBtn = {
  background: 'none', border: 'none', cursor: 'pointer',
  width: 40, height: 40, borderRadius: '50%',
  display: 'flex', alignItems: 'center', justifyContent: 'center',
  color: 'var(--text)',
};

// =================== PLACE DETAIL ===================

function PlaceScreen({ place, city, onBack, onRoute, onChat, dark }) {
  const colorMap = { wow: '#F06B50', kids: '#3B82F6', science: '#8B5CF6', food: '#10B981' };
  const col = colorMap[place.tag] || '#737373';

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Hero with emoji art */}
      <div style={{ height: 240, position: 'relative', background: `linear-gradient(135deg, ${col}33 0%, ${col}11 60%, var(--bg) 100%)`, flexShrink: 0 }}>
        <div style={{
          position: 'absolute', inset: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 100,
        }}>{place.emoji}</div>
        <div style={{ position: 'absolute', top: 8, left: 8, right: 8, display: 'flex', justifyContent: 'space-between' }}>
          <button onClick={onBack} style={{ ...iconBtn, background: 'rgba(255,255,255,0.92)' }}><Ic.back s={22}/></button>
          <button style={{ ...iconBtn, background: 'rgba(255,255,255,0.92)' }}><Ic.star s={20}/></button>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px 80px' }} className="nsb">
        <div style={{ fontSize: 12, color: col, textTransform: 'uppercase', letterSpacing: 0.6, fontWeight: 700 }}>{city.name}</div>
        <div style={{ fontSize: 26, fontWeight: 600, color: 'var(--text)', fontFamily: '"Google Sans", sans-serif', marginTop: 4, letterSpacing: '-0.4px', lineHeight: 1.15 }}>{place.name}</div>
        <div style={{ fontSize: 15, color: 'var(--text-secondary)', marginTop: 6, lineHeight: 1.5 }}>{place.subtitle}</div>

        {/* Quick stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginTop: 16 }}>
          <Stat icon="⏱" label="Время" value={place.dur} />
          <Stat icon="👶" label="Возраст" value={place.age} />
          <Stat icon="💶" label="Цена" value={place.price} />
        </div>

        {/* Address row */}
        <Card style={{ marginTop: 16, padding: 14 }}>
          <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
            <div style={{ width: 40, height: 40, borderRadius: 10, background: 'var(--coral-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--coral-text)' }}><Ic.pin s={20}/></div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, color: 'var(--text)', fontWeight: 500 }}>{place.addr}</div>
              <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>Открыто: {place.open}</div>
            </div>
          </div>
        </Card>

        {/* For kids */}
        <div style={{ marginTop: 18 }}>
          <SectionLabel>Что сказать детям</SectionLabel>
          <Card style={{ background: 'linear-gradient(135deg, #FFF1ED, #FFE6DF)', border: '1px solid #F06B5044' }}>
            <div style={{ display: 'flex', gap: 12 }}>
              <div style={{ fontSize: 32 }}>🧒</div>
              <div style={{ flex: 1, fontSize: 15, color: '#2A1610', lineHeight: 1.5, fontFamily: '"Google Sans Text", sans-serif' }}>
                «{place.kid}»
              </div>
            </div>
          </Card>
        </div>

        {/* Logistics tip */}
        <div style={{ marginTop: 18 }}>
          <SectionLabel>Лайфхак для семьи</SectionLabel>
          <Card style={{ borderLeft: '3px solid #F59E0B' }}>
            <div style={{ display: 'flex', gap: 10 }}>
              <div style={{ fontSize: 20 }}>💡</div>
              <div style={{ flex: 1, fontSize: 14, color: 'var(--text)', lineHeight: 1.5 }}>{place.tip}</div>
            </div>
          </Card>
        </div>

        {/* Sub places suggestion */}
        <div style={{ marginTop: 18 }}>
          <SectionLabel>Рядом</SectionLabel>
          <div style={{ display: 'flex', gap: 10, overflowX: 'auto', paddingBottom: 4 }} className="nsb">
            {window.TRIP[city.id].places.filter(p => p.id !== place.id).slice(0, 4).map(p => (
              <div key={p.id} style={{
                flexShrink: 0, width: 130,
                background: 'var(--surface)', border: '1px solid var(--border)',
                borderRadius: 14, padding: 12,
              }}>
                <div style={{ fontSize: 24 }}>{p.emoji}</div>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)', marginTop: 4 }}>{p.name}</div>
                <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{p.dist}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sticky CTA */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        padding: 16, background: 'linear-gradient(to top, var(--bg) 60%, transparent)',
      }}>
        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={() => onChat({ place, city })} style={{
            ...ctaSecondary, color: 'var(--text)',
          }}><Ic.spark s={18}/> Спросить</button>
          <button onClick={() => onRoute(place, city)} style={ctaPrimary}>
            <Ic.navUp s={18}/> Как добраться
          </button>
        </div>
      </div>
    </div>
  );
}

function Stat({ icon, label, value }) {
  return (
    <div style={{
      background: 'var(--surface)', border: '1px solid var(--border)',
      borderRadius: 14, padding: '10px 12px',
    }}>
      <div style={{ fontSize: 11, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: 0.4, fontWeight: 600 }}>{label}</div>
      <div style={{ fontSize: 14, color: 'var(--text)', fontWeight: 600, marginTop: 2, fontFamily: '"Google Sans Text", sans-serif' }}>{icon} {value}</div>
    </div>
  );
}

function SectionLabel({ children }) {
  return <div style={{ fontSize: 12, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: 0.5, fontWeight: 700, marginBottom: 8 }}>{children}</div>;
}

const ctaPrimary = {
  flex: 2, background: 'var(--coral-btn)', color: '#fff', border: 'none',
  padding: '14px 16px', borderRadius: 16, cursor: 'pointer',
  fontSize: 15, fontWeight: 600, fontFamily: '"Google Sans Text", sans-serif',
  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
  boxShadow: '0 4px 16px rgba(240,107,80,0.35)',
};
const ctaSecondary = {
  flex: 1, background: 'var(--surface)', border: '1px solid var(--border-strong)',
  padding: '14px 16px', borderRadius: 16, cursor: 'pointer',
  fontSize: 15, fontWeight: 600, fontFamily: '"Google Sans Text", sans-serif',
  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
};

Object.assign(window, {
  Chip, Card, ScreenHeader, BottomNav, FAB,
  HomeMapScreen, CityScreen, PlaceScreen, PlaceListItem, Stat, SectionLabel,
  iconBtn, ctaPrimary, ctaSecondary,
});
