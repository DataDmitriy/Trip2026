// icons.jsx — Inline SVG icons (Material-style, 1.5–2px stroke)

const Ic = {};
const mk = (path) => ({ s = 24, style }) => (
  <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={style}>
    {path}
  </svg>
);
const mkFilled = (path) => ({ s = 24, style }) => (
  <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor" style={style}>{path}</svg>
);

Ic.back = mk(<path d="M19 12H5M12 19l-7-7 7-7" />);
Ic.search = mk(<><circle cx="11" cy="11" r="7"/><path d="M21 21l-5-5"/></>);
Ic.more = mk(<><circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/></>);
Ic.map = mk(<><polygon points="3 6 9 4 15 6 21 4 21 18 15 20 9 18 3 20 3 6"/><line x1="9" y1="4" x2="9" y2="18"/><line x1="15" y1="6" x2="15" y2="20"/></>);
Ic.cal = mk(<><rect x="3" y="5" width="18" height="16" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="8" y1="3" x2="8" y2="7"/><line x1="16" y1="3" x2="16" y2="7"/></>);
Ic.chat = mk(<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>);
Ic.flight = mk(<path d="M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1L15 22v-1.5L13 19v-5.5z"/>);
Ic.spark = mk(<><path d="M12 3l1.9 5.5L19 10l-5.1 1.5L12 17l-1.9-5.5L5 10l5.1-1.5z"/><path d="M19 16l.9 2.4L22 19l-2.1.6L19 22l-.9-2.4L16 19l2.1-.6z"/></>);
Ic.send = mk(<path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/>);
Ic.pin = mk(<><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></>);
Ic.star = mk(<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>);
Ic.navUp = mk(<polygon points="3 11 22 2 13 21 11 13 3 11"/>);
Ic.filter = mk(<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>);
Ic.car = mk(<><rect x="3" y="11" width="18" height="7" rx="2"/><path d="M5 11l2-5h10l2 5"/><circle cx="7" cy="18" r="1.5"/><circle cx="17" cy="18" r="1.5"/></>);
Ic.train = mk(<><rect x="6" y="3" width="12" height="14" rx="2"/><line x1="6" y1="11" x2="18" y2="11"/><circle cx="9" cy="14" r="0.5" fill="currentColor"/><circle cx="15" cy="14" r="0.5" fill="currentColor"/><path d="M8 21l-2 2M16 21l2 2"/></>);
Ic.bus = mk(<><rect x="4" y="4" width="16" height="13" rx="2"/><line x1="4" y1="11" x2="20" y2="11"/><circle cx="8" cy="14" r="1"/><circle cx="16" cy="14" r="1"/><path d="M7 17v3M17 17v3"/></>);
Ic.walk = mk(<><circle cx="13" cy="4" r="2"/><path d="M9 21l3-7 3 3 4-2"/><path d="M9 14l3-3 3 3"/></>);
Ic.bed = mk(<><path d="M2 4v16M22 12v8M2 12h20"/><circle cx="7" cy="9" r="2"/><path d="M11 12V8h7a3 3 0 0 1 3 3v1"/></>);
Ic.moon = mk(<path d="M21 13A9 9 0 1 1 11 3a7 7 0 0 0 10 10z"/>);
Ic.check = mk(<polyline points="20 6 9 17 4 12"/>);
Ic.bag = mk(<><rect x="5" y="7" width="14" height="14" rx="2"/><path d="M9 7V5a3 3 0 0 1 6 0v2"/></>);
Ic.euro = mk(<><path d="M18 7a6 6 0 1 0 0 10"/><line x1="3" y1="10" x2="13" y2="10"/><line x1="3" y1="14" x2="13" y2="14"/></>);
Ic.device = mk(<><rect x="6" y="2" width="12" height="20" rx="3"/><line x1="11" y1="18" x2="13" y2="18"/></>);
Ic.close = mk(<><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></>);
Ic.sun = mk(<><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></>);

window.Ic = Ic;
