# Handoff: Trip Helper — Семейный помощник для путешествия

## Обзор

Mobile app (Android-first, Material 3) — помощник для семейной поездки на 16 дней по маршруту **Будапешт → Париж/Disneyland → Биллунн (Леголенд) → Амстердам**. Семья: 2 взрослых + 3 детей (2, 5, 6 лет).

Главные ограничения, на которые заточен дизайн:
- **Без коляски** — пешие переходы ≤ 800 м
- **Сон младшего 13:00–15:00** — обязательное возвращение в апартаменты к 12:45
- **5 ручных кладей + 1 чемодан** — никаких многоступенчатых пересадок
- **9 экранов**, кликабельный prototype

## О файлах в этой папке

Файлы в этой папке — это **дизайн-референс, реализованный в HTML/React** через `<script type="text/babel">` и Babel-standalone в браузере. Это **не production-код для прямого копирования**. Задача — **воспроизвести эти HTML-дизайны в целевой кодовой базе** (Kotlin/Jetpack Compose, React Native, Flutter — на ваш выбор), используя её существующие паттерны и библиотеки.

Если кодовой базы ещё нет — рекомендуется **React Native + Expo** (быстрый старт) или **Jetpack Compose** (нативный Android Material 3, что соответствует дизайну 1:1).

## Уровень детализации (Fidelity)

**High-fidelity (hifi)** — пиксель-в-пиксель макапы с финальными цветами, типографикой, отступами и интеракциями. Все 9 экранов уже сверстаны и кликабельны. Все данные (места, перелёты, расписание) — реальные, извлечённые из исследовательского документа пользователя.

---

## Архитектура и навигация

### Структура экранов

Приложение использует **bottom navigation (5 табов)** + **stack-based push для деталей**:

```
Bottom tabs:
├─ Карта (HomeMapScreen)         ← главный экран, карта Европы со всеми точками
├─ По дням (DaysScreen)          ← вертикальный таймлайн 16 дней
├─ AI помощник (ChatScreen)      ← контекстный чат
├─ Перелёты (FlightsScreen)      ← 4 рейса + багаж
└─ Ещё (MoreScreen)              ← меню → Багаж, Бюджет, Фильтры

Stack push (поверх bottom nav):
├─ CityScreen        ← открывается с карты по клику на город
├─ PlaceScreen       ← карточка места (зоопарк, Disneyland и т.д.)
├─ RouteScreen       ← пошаговый маршрут от жилья до места
└─ FiltersScreen     ← детские фильтры (возраст, дистанция, режим сна)
```

### Навигационные паттерны
- Тап на пин на карте Европы → `CityScreen`
- Тап на пин на карте города → bottom button «Открыть [место]» → `PlaceScreen`
- В `PlaceScreen` две CTA: «Спросить» (→ Chat с контекстом места) и «Как добраться» (→ `RouteScreen`)
- AI помощник умеет принимать контекст (`{ city }` или `{ place, city }`) — использует его для seed-сообщения и подсказанных промптов

---

## Дизайн-токены

### Цвета (light theme)

```
--bg:              #FFF8F1   (фон экрана, тёплый кремовый)
--surface:         #FFFFFF   (карточки)
--text:            #1F1714   (основной текст, тёплый чёрный)
--text-secondary:  #6B5F58   (вторичный текст)
--border:          #ECE2D4   (границы карточек)
--border-strong:   #D9CABB   (более выраженные границы)
--coral-text:      #C84F38   (акцент текст/иконки)
--coral-btn:       #F06B50   (CTA кнопки)
--coral-soft:      #FFE9DF   (фон tinted-зон)
--chip-bg:         #F4EBDF   (фон неактивных чипов)
```

### Цвета (dark theme)

```
--bg:              #14110F
--surface:         #1F1B18
--text:            #F2EBE3
--text-secondary:  #A39588
--border:          #2F2925
--border-strong:   #4A413A
--coral-text:      #FF8266
--coral-btn:       #F06B50
--coral-soft:      #3A2419
--chip-bg:         #2A2420
```

### Семантические цвета (одинаковы в обеих темах)

```
Этапы маршрута (города):
  Будапешт:   #C84F38   (терракотовый)
  Париж:      #3B6FB8   (синий)
  Биллунн:    #2F8C5A   (зелёный)
  Амстердам:  #7A4FA8   (фиолетовый)

Категории мест:
  wow / Главное:  #F06B50  (коралл)
  kids / Дети:    #3B82F6  (синий)
  science:        #8B5CF6  (фиолетовый)
  food:           #10B981  (зелёный)

Транспорт:
  flight (перелёт): #3B82F6
  taxi:             #F59E0B
  transit:          #8B5CF6
  walk:             #10B981
  rest (жильё):     #737373
  nap (сон):        #6366F1   (важная категория — задаёт ритм дня)
  food:             #10B981
  place:            #F06B50
```

### Типографика

```
Headings (h1, screen titles):    'Google Sans', 600, 28px, letter-spacing -0.5px, line-height 1.2
Section labels (uppercase):      'Google Sans Text', 700, 12px, letter-spacing 0.5px
Body:                            'Google Sans Text', 400/500, 14px–15px, line-height 1.5
Numeric / monospace (times):     'JetBrains Mono', 400/600/700
Button:                          'Google Sans Text', 600, 14px–15px
```

### Размеры и отступы

```
Радиусы:
  Pills / chips:          100px
  Cards:                  16–20px (стандарт), 24px (большие, hero)
  Bottom sheet top:       28px
  CTA buttons:            14–16px
  Small:                  6–10px

Отступы экранов:
  Horizontal padding:     16–20px
  Card padding:           14–16px
  Gap между элементами:   8–14px

Hit-targets:
  Минимум:                44×44px
  Bottom nav иконки:      48px высота (вкладки)
  FAB:                    44px (внутри 48px touch)
```

### Тени

```
Карточки:           1px solid var(--border) — без тени
Floating buttons:   0 2px 8px rgba(0,0,0,0.1)
Coral CTA:          0 4px 16px rgba(240,107,80,0.35)
Bottom sheet:       0 -2px 24px rgba(0,0,0,0.1)
Top search bar:     0 2px 8px rgba(0,0,0,0.06)
```

---

## Экраны (детали)

### 1. HomeMapScreen — Главная карта Европы
- **Layout**: Full-bleed «бумажная» SVG-карта Европы + плавающий поисковый бар сверху + горизонтальный скролл-список «Этапы маршрута» снизу (как sibling, НЕ перекрывая bottom nav)
- **Карта**: 4 пина (1, 2, 3, 4) с цветами этапа, соединены пунктирной кривой. Стиль — paper / topographic (узор сетки + волны рельефа).
- **Search bar**: pill 48px, иконка лупы слева, аватар справа, текст-плейсхолдер «Куда сейчас?»
- **Today badge** (top-right под search): coral pill «📍 Сейчас: Париж» (контекстно меняется)
- **Floating actions** (правый край): FAB фильтр + FAB навигация
- **City cards** (горизонтальный скролл, 168px ширина): тег этапа («Этап 1»), название города, страна, даты. Активный — заливка цветом этапа.

### 2. CityScreen — Город
- **Layout**: Header large (с back) + hero map 220px + chip-фильтры + scroll list мест
- **Hero map**: SVG карта района, центр — иконка дома, вокруг 5–6 пинов с эмодзи. По тапу на пин — фокус + всплывает coral CTA «Открыть [место]».
- **Chips**: «Всё (N)», «🤩 Главное», «🧸 Для детей», «🔬 Наука», «🍽 Еда»
- **Stay card** (всегда первая): coral акцент сверху, дом-эмодзи, адрес, метро
- **Place list items**: 56px эмодзи-квадрат с цветным фоном (по категории), название, MUST-бейдж для wow, метаданные (дистанция, время, возраст)
- **AI nudge** в конце списка: dashed border, спарк-иконка, «Спросить помощника · "Куда пойти прямо сейчас в [город]?"»

### 3. PlaceScreen — Карточка места
- **Hero** 240px: градиентный фон по категории + большое эмодзи 100px по центру
- **Header**: кнопки back и star — на полупрозрачных белых кружках 40px
- **Контент**:
  - Тег категории (uppercase цветной)
  - Название 26px
  - Подзаголовок
  - **3 stat-карточки** (grid 1fr×3): Время, Возраст, Цена
  - **Address card**: pin-иконка + адрес + часы работы
  - **«Что сказать детям»**: coral-soft градиент карточка + 32px эмодзи + цитата фразы
  - **«Лайфхак для семьи»**: orange-border-left card с лампочкой
  - **«Рядом»**: горизонтальный скролл соседних мест 130px
- **Sticky bottom CTA**: «Спросить» (secondary) + «Как добраться» (primary, flex 2)

### 4. DaysScreen — Дневник по дням
- **Header large**: «Дневник по дням», sub «6 мая → 22 мая · 16 дней»
- **Timeline strip** (горизонтальный): 16 дневных карточек 92px, цвет по этапу города, top-border 3px цвет, активный — заливка цветом
- **Day detail**:
  - Дата + label
  - **Vertical timeline**: левая колонка 52px с временем в моноспейсе, центр — 32px цветной кружок с иконкой типа активности, справа — карточка с label/text
  - **Nap (сон)** — особый styling: фиолетовый градиент `#EEF0FF → #E5E9FF`, бейдж «⛔ Без транзита, без шоппинга — только дома»
  - Items с `placeId` кликабельны → открывают PlaceScreen

### 5. ChatScreen — AI помощник
- **Header large** + speech-bubble иконка
- **Сообщения**:
  - AI: 32px coral аватар (spark icon) + bubble (surface, border, radius `4px 16px 16px 16px`)
  - User: bubble справа (coral-btn fill, white text, radius `16px 4px 16px 16px`)
  - **Suggestions inside AI bubble**: белые мини-карточки с title + subtitle (для рекомендаций мест)
- **Quick prompts** (показываются на старте): вертикальный список тапабельных строк с иконками
- **Input**: pill 24px радиус, текстовое поле + 40px circle send-button (coral когда есть текст, иначе серый)
- **Контекстные ответы** (см. `generateReply` в screens2.jsx) — обрабатывают: «куда пойти», «дождь», «еда», «сон Лёвы», «перелёт», «рядом»

### 6. RouteScreen — Маршрут
- **Header**: simple с back
- **Summary card** (coral-soft градиент): большое число «N мин в пути» + ETA + визуальный route 🏠 — — — 📍
- **Section: Шаги**
  - Start card («Откуда»): дом
  - **Step rows**: левая 40px колонка с цветным connector + центр-карточка с круглой цветной иконкой (walk/bus/train/car) + label/distance + минуты справа в моноспейсе
  - End card («Куда»): эмодзи места, coral highlight
- **Section: Семейные нюансы** — карточка с advice-строками (✅ для good, эмодзи для warning):
  - Лимит 800 м для Лёвы
  - Пересадок: 0 (критично с 5 кладями)
  - Прогноз погоды
  - Запас до сна
- **Sticky CTA**: «Запустить навигацию» full-width

### 7. FlightsScreen — Перелёты
- **4 flight cards** для KIV→BUD, BUD→CDG, CDG→BLL, AMS→KIV
- **Layout карточки**: header с датой/кодом → grid с FROM (28px airport code, время моноспейс) | center (длительность, dashed line с самолёт-иконкой по центру, авиакомпания) | TO
- **Tip block**: coral-soft pill с лампочкой и предупреждением (например: «Конфликт со сном Лёвы 13:00–15:00»)
- **Baggage section**: 1×чемодан 23 кг + 5×ручная кладь

### 8. BaggageScreen — Чек-лист
- **Progress card**: conic-gradient circle 56px показывает % собрано + текст «До вылета 6 дней»
- **Группы**: Документы, Дети, Снаряжение
- **Item row**: 22px чекбокс (coral fill при `done`) + текст (line-through + opacity 0.5 если done). Клик переключает состояние.

### 9. BudgetScreen — Бюджет
- **Big number card**: «Потрачено / план», 40px моноспейс число, мульти-сегментный прогресс-бар (10px высота, скомпонованный из всех категорий)
- **Category cards**: 10×38px цветной маркер слева + название + потрачено/план в моноспейсе + индивидуальный прогресс-бар 4px

### MoreScreen — Меню
Простой список с 40px coral-soft icon + label + sub + chevron «→». Пункты: Багаж, Бюджет, Детские фильтры, Семья, Настройки.

### FiltersScreen — Детские фильтры
- Возраст: 4 segmented buttons (2/3/5/6)
- Слайдер дистанции 0.3–3 км (accent-color coral)
- Toggle строки (44×26 switch coral fill при on): «Учитывать сон Лёвы», «Только открытые сейчас», и т.д.

---

## Bottom Navigation

5 табов: Карта / По дням / AI помощник / Перелёты / Ещё. Активный — coral-text цвет, иконка в pill (40×24 coral-soft фон), label 11px 600. Неактивный — text-secondary, без pill.

---

## Состояния и интеракции

```ts
type AppState = {
  tab: 'map' | 'days' | 'chat' | 'flights' | 'more' | 'baggage' | 'budget';
  stack: Array<{ kind: 'city' | 'place' | 'route' | 'filters'; payload: any }>;
  chatCtx: { city?: City; place?: Place } | null;
  theme: 'light' | 'dark';
};
```

**Push-pop**: тап на сущность пушит в stack, header back popпает. Tab change при пустом stack меняет таб; при непустом — сначала очищает stack.

**AI чат с контекстом**: открытие чата из Place/City передаёт ctx → seed-сообщение и предложенные промпты меняются.

**Чек-лист багажа** — локальное состояние, переключается тапом на строку (не только чекбокс).

---

## Данные (`data.js`)

Содержит реальные данные (не фейк):
- 4 города с координатами для карты Европы
- 4 перелёта (Wizz Air, Air France, KLM) с реальными кодами рейсов и заметками
- ~22 места с реальными адресами, часами работы, ценами, советами «что сказать детям»
- Дневное расписание для 16 дней с обязательным окном сна 13:00–15:00
- Чек-лист багажа (3 группы), бюджет (5 категорий)

В реальном приложении эти данные должны храниться в БД (SQLite/Realm для оффлайн) или приходить с бэкенда. Структура данных в `data.js` подходит как стартовая схема.

---

## AI помощник — реализация

В прототипе AI отвечает по простым keyword-rules (`generateReply`). В production:
- **Anthropic Claude API** с `claude-haiku-4-5` или `claude-sonnet-4`
- **System prompt** должен включать: маршрут, состав семьи, ограничения (сон, коляска, багаж), текущее время и место
- **Tools / function calling**: `get_place(id)`, `find_nearby(category, radius)`, `check_weather(city, date)`, `get_schedule(date)`
- **Контекст** передавать как `additional_context` при открытии чата с конкретного места

---

## Что делать разработчику

1. Откройте `app.html` в браузере — это полный кликабельный прототип. Используйте Tweaks (правый низ) для переключения Pixel 10 / Pixel 8 Pro / Оба, light/dark.
2. Прочитайте `screens.jsx` и `screens2.jsx` — там вся вёрстка и логика экранов. Inline-стили — намеренно, для удобства чтения дизайна.
3. Прочитайте `data.js` — реальные данные на 16 дней.
4. Прочитайте `maps.jsx` — кастомные SVG-карты (Европа + город), стилистика «paper / topographic». В production замените на **Mapbox** или **Google Maps SDK** с custom style JSON, имитирующим эту палитру.
5. Прочитайте `icons.jsx` — все иконки. В production используйте **Material Symbols** или **Phosphor Icons** — тот же visual weight (2px stroke).
6. Воспроизведите дизайн в **Jetpack Compose / React Native / Flutter** в существующих паттернах вашего проекта.

## Файлы

- `app.html` — точка входа, layout двух девайсов, tweaks panel
- `data.js` — все данные путешествия (cities, flights, places, days, baggage, budget)
- `icons.jsx` — SVG-иконки (Material-style, 2px stroke)
- `maps.jsx` — `EuropeMap` (overview) и `CityMap` (street-level)
- `screens.jsx` — Home, City, Place + shared primitives (Card, Chip, Header, BottomNav, FAB)
- `screens2.jsx` — Days, Chat, Route, Flights, Baggage, Budget, More, Filters
- `android-frame.jsx` — Material 3 device frame (status bar, app bar, gesture nav, keyboard)
- `tweaks-panel.jsx` — design-time tweak controls (можно удалить в production)

---

## Зависимости (production)

Рекомендуемый стек (Jetpack Compose):
- `androidx.compose.material3:material3` — Material 3 components
- `androidx.navigation:navigation-compose` — навигация
- `com.google.maps.android:maps-compose` — Google Maps + custom style
- `io.coil-kt:coil-compose` — изображения
- `com.anthropic:anthropic-sdk-java` — AI чат

Шрифты: Google Sans (через Google Fonts) + JetBrains Mono.
